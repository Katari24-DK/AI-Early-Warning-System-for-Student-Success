"""
Predictive Modeling Engine for Student Success
Implements multiple ML models for risk prediction
"""

import numpy as np
import pandas as pd
import pickle
import json
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)
import warnings
warnings.filterwarnings('ignore')

class PredictiveModelEngine:
    """Main engine for managing multiple predictive models"""
    
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.feature_names = [
            'attendance', 'grade_average', 'time_on_task',
            'lms_logins_per_week', 'missing_assignments', 'prior_risk_flag'
        ]
        self.model_performance = {}
        self.training_data = None
        self.test_data = None
        
    def create_models(self) -> Dict:
        """Initialize all model types"""
        self.models = {
            'xgboost': GradientBoostingClassifier(
                n_estimators=100,
                learning_rate=0.1,
                max_depth=5,
                random_state=42
            ),
            'random_forest': RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                n_jobs=-1
            ),
            'logistic_regression': LogisticRegression(
                max_iter=1000,
                random_state=42
            ),
            'neural_network': MLPClassifier(
                hidden_layer_sizes=(100, 50),
                max_iter=1000,
                random_state=42,
                early_stopping=True
            )
        }
        return {"status": "Models created", "models": list(self.models.keys())}
    
    def prepare_data(self, data: List[Dict], risk_threshold: float = 0.6) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prepare data for training
        
        Args:
            data: List of student records
            risk_threshold: Threshold for classifying as at-risk
        
        Returns:
            Tuple of (X, y) for training
        """
        X = []
        y = []
        
        for record in data:
            features = [
                record.get('attendance', 80),
                record.get('grade_average', 75),
                record.get('time_on_task', 50),
                record.get('lms_logins_per_week', 1),
                record.get('missing_assignments', 0),
                record.get('prior_risk_flag', 0)
            ]
            X.append(features)
            
            # Calculate risk score to determine label
            risk_score = self._calculate_risk_score(record)
            y.append(1 if risk_score > risk_threshold else 0)
        
        return np.array(X), np.array(y)
    
    def train_models(self, X: np.ndarray, y: np.ndarray, test_size: float = 0.2) -> Dict:
        """
        Train all models on the provided data
        
        Args:
            X: Feature matrix
            y: Target labels
            test_size: Proportion of data to use for testing
        
        Returns:
            Dictionary with training results
        """
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        
        self.training_data = (X_train, y_train)
        self.test_data = (X_test, y_test)
        
        results = {}
        
        for model_name, model in self.models.items():
            # Scale features for models that benefit from it
            if model_name in ['logistic_regression', 'neural_network']:
                scaler = StandardScaler()
                X_train_scaled = scaler.fit_transform(X_train)
                X_test_scaled = scaler.transform(X_test)
                self.scalers[model_name] = scaler
            else:
                X_train_scaled = X_train
                X_test_scaled = X_test
            
            # Train model
            model.fit(X_train_scaled, y_train)
            
            # Evaluate
            y_pred = model.predict(X_test_scaled)
            y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
            
            # Calculate metrics
            metrics = {
                'accuracy': float(accuracy_score(y_test, y_pred)),
                'precision': float(precision_score(y_test, y_pred, zero_division=0)),
                'recall': float(recall_score(y_test, y_pred, zero_division=0)),
                'f1': float(f1_score(y_test, y_pred, zero_division=0)),
                'roc_auc': float(roc_auc_score(y_test, y_pred_proba)),
            }
            
            self.model_performance[model_name] = metrics
            results[model_name] = metrics
        
        return {
            "status": "Training complete",
            "models_trained": len(self.models),
            "training_samples": len(X_train),
            "test_samples": len(X_test),
            "performance": results
        }
    
    def predict(self, features: List[float], model_name: str = 'xgboost') -> Dict:
        """
        Make prediction using specified model
        
        Args:
            features: List of feature values
            model_name: Name of model to use
        
        Returns:
            Dictionary with prediction and confidence
        """
        if model_name not in self.models:
            return {"error": f"Model {model_name} not found"}
        
        X = np.array(features).reshape(1, -1)
        
        # Scale if necessary
        if model_name in self.scalers:
            X = self.scalers[model_name].transform(X)
        
        model = self.models[model_name]
        prediction = model.predict(X)[0]
        probability = model.predict_proba(X)[0]
        
        return {
            "model": model_name,
            "prediction": int(prediction),
            "at_risk": bool(prediction == 1),
            "risk_probability": float(probability[1]),
            "safe_probability": float(probability[0]),
            "confidence": float(max(probability))
        }
    
    def predict_batch(self, records: List[Dict], model_name: str = 'xgboost') -> List[Dict]:
        """
        Make predictions for multiple students
        
        Args:
            records: List of student records
            model_name: Name of model to use
        
        Returns:
            List of predictions
        """
        predictions = []
        for record in records:
            features = [
                record.get('attendance', 80),
                record.get('grade_average', 75),
                record.get('time_on_task', 50),
                record.get('lms_logins_per_week', 1),
                record.get('missing_assignments', 0),
                record.get('prior_risk_flag', 0)
            ]
            
            pred = self.predict(features, model_name)
            pred['student_id'] = record.get('student_id', 'Unknown')
            predictions.append(pred)
        
        return predictions
    
    def get_model_comparison(self) -> Dict:
        """Get performance comparison across all models"""
        return {
            "timestamp": datetime.now().isoformat(),
            "models": self.model_performance,
            "best_model": max(
                self.model_performance.items(),
                key=lambda x: x[1]['f1']
            )[0] if self.model_performance else None
        }
    
    def save_models(self, filepath: str = "models/") -> Dict:
        """Save all trained models to disk"""
        import os
        os.makedirs(filepath, exist_ok=True)
        
        saved_models = []
        for model_name, model in self.models.items():
            model_path = f"{filepath}{model_name}_model.pkl"
            with open(model_path, 'wb') as f:
                pickle.dump(model, f)
            saved_models.append(model_name)
            
            # Save scaler if exists
            if model_name in self.scalers:
                scaler_path = f"{filepath}{model_name}_scaler.pkl"
                with open(scaler_path, 'wb') as f:
                    pickle.dump(self.scalers[model_name], f)
        
        return {
            "status": "Models saved",
            "models": saved_models,
            "filepath": filepath
        }
    
    def load_models(self, filepath: str = "models/") -> Dict:
        """Load trained models from disk"""
        import os
        
        loaded_models = []
        for model_name in self.models.keys():
            model_path = f"{filepath}{model_name}_model.pkl"
            if os.path.exists(model_path):
                with open(model_path, 'rb') as f:
                    self.models[model_name] = pickle.load(f)
                loaded_models.append(model_name)
                
                # Load scaler if exists
                scaler_path = f"{filepath}{model_name}_scaler.pkl"
                if os.path.exists(scaler_path):
                    with open(scaler_path, 'rb') as f:
                        self.scalers[model_name] = pickle.load(f)
        
        return {
            "status": "Models loaded",
            "models": loaded_models,
            "filepath": filepath
        }
    
    def _calculate_risk_score(self, record: Dict) -> float:
        """Calculate risk score for a student record"""
        risk_score = 0.0
        
        attendance = record.get('attendance', 80)
        if attendance < 80:
            risk_score += (80 - attendance) / 100 * 0.3
        
        grade_average = record.get('grade_average', 75)
        if grade_average < 70:
            risk_score += (70 - grade_average) / 100 * 0.3
        
        time_on_task = record.get('time_on_task', 50)
        if time_on_task < 40:
            risk_score += (40 - time_on_task) / 100 * 0.2
        
        lms_logins = record.get('lms_logins_per_week', 1)
        if lms_logins < 2:
            risk_score += (2 - lms_logins) / 2 * 0.1
        
        missing_assignments = record.get('missing_assignments', 0)
        if missing_assignments > 2:
            risk_score += min(missing_assignments / 10, 0.1)
        
        if record.get('prior_risk_flag', 0) == 1:
            risk_score += 0.1
        
        return min(risk_score, 1.0)

# Global engine instance
engine = PredictiveModelEngine()

def generate_sample_training_data(n_samples: int = 500) -> List[Dict]:
    """Generate synthetic training data for demonstration"""
    np.random.seed(42)
    data = []
    
    for i in range(n_samples):
        # Generate correlated features
        at_risk = np.random.choice([0, 1], p=[0.7, 0.3])
        
        if at_risk:
            attendance = np.random.normal(70, 10)
            grade_average = np.random.normal(65, 12)
            time_on_task = np.random.normal(35, 15)
            lms_logins = np.random.normal(1, 0.5)
            missing_assignments = np.random.randint(2, 8)
        else:
            attendance = np.random.normal(88, 8)
            grade_average = np.random.normal(80, 10)
            time_on_task = np.random.normal(55, 12)
            lms_logins = np.random.normal(3, 1)
            missing_assignments = np.random.randint(0, 2)
        
        record = {
            'student_id': f'S-{i:04d}',
            'attendance': max(50, min(100, attendance)),
            'grade_average': max(0, min(100, grade_average)),
            'time_on_task': max(0, time_on_task),
            'lms_logins_per_week': max(0, lms_logins),
            'missing_assignments': int(max(0, missing_assignments)),
            'prior_risk_flag': at_risk
        }
        data.append(record)
    
    return data

if __name__ == "__main__":
    # Example usage
    print("Initializing Predictive Model Engine...")
    engine.create_models()
    
    print("Generating sample training data...")
    training_data = generate_sample_training_data(500)
    
    print("Preparing data...")
    X, y = engine.prepare_data(training_data)
    
    print("Training models...")
    results = engine.train_models(X, y)
    print(json.dumps(results, indent=2))
    
    print("\nModel Comparison:")
    comparison = engine.get_model_comparison()
    print(json.dumps(comparison, indent=2))
    
    print("\nSample Prediction:")
    sample_features = [85, 75, 50, 2, 1, 0]
    prediction = engine.predict(sample_features)
    print(json.dumps(prediction, indent=2))
