"""
LangGraph Agent System for Student Success
Provides intelligent analysis and intervention recommendations
"""

import anthropic
import json
from typing import Optional
from datetime import datetime

# Initialize Anthropic client
client = anthropic.Anthropic()

# Define tools for the agent
tools = [
    {
        "name": "analyze_student_metrics",
        "description": "Analyze student performance metrics and identify risk factors",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {
                    "type": "string",
                    "description": "The student ID"
                },
                "attendance": {
                    "type": "number",
                    "description": "Attendance percentage (0-100)"
                },
                "grade_average": {
                    "type": "number",
                    "description": "Average grade (0-100)"
                },
                "time_on_task": {
                    "type": "number",
                    "description": "Average time on task in minutes"
                },
                "lms_logins_per_week": {
                    "type": "number",
                    "description": "Number of LMS logins per week"
                },
                "missing_assignments": {
                    "type": "integer",
                    "description": "Number of missing assignments"
                }
            },
            "required": ["student_id", "attendance", "grade_average", "time_on_task", "lms_logins_per_week", "missing_assignments"]
        }
    },
    {
        "name": "generate_intervention_plan",
        "description": "Generate a personalized intervention plan based on risk factors",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {
                    "type": "string",
                    "description": "The student ID"
                },
                "risk_factors": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of identified risk factors"
                },
                "risk_score": {
                    "type": "number",
                    "description": "Overall risk score (0-1)"
                }
            },
            "required": ["student_id", "risk_factors", "risk_score"]
        }
    },
    {
        "name": "recommend_resources",
        "description": "Recommend specific resources and support services",
        "input_schema": {
            "type": "object",
            "properties": {
                "student_id": {
                    "type": "string",
                    "description": "The student ID"
                },
                "intervention_type": {
                    "type": "string",
                    "enum": ["academic", "engagement", "attendance", "mental_health", "financial"],
                    "description": "Type of intervention needed"
                }
            },
            "required": ["student_id", "intervention_type"]
        }
    }
]

def analyze_student_metrics(student_id: str, attendance: float, grade_average: float, 
                           time_on_task: float, lms_logins_per_week: float, 
                           missing_assignments: int) -> dict:
    """Analyze student metrics and identify risk factors"""
    risk_factors = []
    
    if attendance < 80:
        risk_factors.append(f"Low attendance ({attendance}%)")
    if grade_average < 70:
        risk_factors.append(f"Low grade average ({grade_average})")
    if time_on_task < 40:
        risk_factors.append(f"Low time on task ({time_on_task} minutes)")
    if lms_logins_per_week < 2:
        risk_factors.append(f"Low LMS engagement ({lms_logins_per_week} logins/week)")
    if missing_assignments > 2:
        risk_factors.append(f"Multiple missing assignments ({missing_assignments})")
    
    return {
        "student_id": student_id,
        "risk_factors": risk_factors,
        "factor_count": len(risk_factors),
        "analysis": f"Student {student_id} has {len(risk_factors)} identified risk factors"
    }

def generate_intervention_plan(student_id: str, risk_factors: list, risk_score: float) -> dict:
    """Generate personalized intervention plan"""
    interventions = []
    
    if risk_score > 0.8:
        interventions.append("Schedule urgent meeting with academic advisor")
        interventions.append("Refer to tutoring services immediately")
        interventions.append("Contact student to assess barriers to success")
    elif risk_score > 0.6:
        interventions.append("Schedule meeting with academic advisor")
        interventions.append("Recommend tutoring services")
        interventions.append("Increase check-in frequency")
    else:
        interventions.append("Monitor student progress")
        interventions.append("Provide encouragement and support")
    
    # Add specific interventions based on risk factors
    for factor in risk_factors:
        if "attendance" in factor.lower():
            interventions.append("Discuss attendance barriers and create attendance plan")
        if "grade" in factor.lower():
            interventions.append("Identify struggling subjects and arrange peer tutoring")
        if "engagement" in factor.lower():
            interventions.append("Encourage participation in study groups")
        if "assignment" in factor.lower():
            interventions.append("Help develop time management and assignment tracking system")
    
    return {
        "student_id": student_id,
        "risk_level": "critical" if risk_score > 0.8 else "warning" if risk_score > 0.6 else "low",
        "interventions": list(set(interventions)),  # Remove duplicates
        "priority": "high" if risk_score > 0.7 else "medium" if risk_score > 0.5 else "low"
    }

def recommend_resources(student_id: str, intervention_type: str) -> dict:
    """Recommend specific resources and support services"""
    resources = {
        "academic": [
            "Tutoring Center - Available Mon-Fri 9am-5pm",
            "Writing Center - Drop-in support for essays",
            "Study Skills Workshop - Thursdays at 3pm",
            "Peer Tutoring Program - Free one-on-one sessions"
        ],
        "engagement": [
            "Study Groups - Join existing groups or create new ones",
            "Learning Communities - Connect with peers in your major",
            "Online Discussion Forums - Engage with classmates",
            "Office Hours - Meet with instructors regularly"
        ],
        "attendance": [
            "Attendance Support Program - Help with barriers",
            "Transportation Assistance - Available for eligible students",
            "Childcare Resources - On-campus and partner facilities",
            "Health Services - Address health-related absences"
        ],
        "mental_health": [
            "Counseling Services - Free confidential counseling",
            "Peer Support Groups - Connect with others",
            "Stress Management Workshops - Learn coping strategies",
            "Crisis Hotline - 24/7 support available"
        ],
        "financial": [
            "Financial Aid Office - Review funding options",
            "Emergency Grants - Available for eligible students",
            "Work-Study Program - On-campus employment",
            "Scholarship Opportunities - Additional funding sources"
        ]
    }
    
    return {
        "student_id": student_id,
        "intervention_type": intervention_type,
        "resources": resources.get(intervention_type, []),
        "next_steps": f"Contact the appropriate office to access {intervention_type} resources"
    }

def process_tool_call(tool_name: str, tool_input: dict) -> str:
    """Process tool calls from the agent"""
    if tool_name == "analyze_student_metrics":
        result = analyze_student_metrics(**tool_input)
    elif tool_name == "generate_intervention_plan":
        result = generate_intervention_plan(**tool_input)
    elif tool_name == "recommend_resources":
        result = recommend_resources(**tool_input)
    else:
        result = {"error": f"Unknown tool: {tool_name}"}
    
    return json.dumps(result)

def run_agent(student_data: dict) -> dict:
    """
    Run the LangGraph agent to analyze student and generate recommendations
    
    Args:
        student_data: Dictionary containing student information
    
    Returns:
        Dictionary with analysis and recommendations
    """
    
    # Prepare the initial prompt
    prompt = f"""
    Analyze the following student data and provide comprehensive intervention recommendations:
    
    Student ID: {student_data.get('student_id', 'Unknown')}
    Attendance: {student_data.get('attendance', 0)}%
    Grade Average: {student_data.get('grade_average', 0)}
    Time on Task: {student_data.get('time_on_task', 0)} minutes
    LMS Logins per Week: {student_data.get('lms_logins_per_week', 0)}
    Missing Assignments: {student_data.get('missing_assignments', 0)}
    
    Please:
    1. Analyze the student metrics to identify risk factors
    2. Generate a personalized intervention plan
    3. Recommend specific resources based on the identified needs
    4. Provide a summary of recommended actions
    """
    
    messages = [{"role": "user", "content": prompt}]
    
    # Agentic loop
    max_iterations = 10
    iteration = 0
    
    while iteration < max_iterations:
        iteration += 1
        
        # Call Claude with tools
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=4096,
            tools=tools,
            messages=messages
        )
        
        # Check if we're done
        if response.stop_reason == "end_turn":
            # Extract final response
            final_response = ""
            for block in response.content:
                if hasattr(block, 'text'):
                    final_response = block.text
            
            return {
                "status": "success",
                "student_id": student_data.get('student_id'),
                "analysis": final_response,
                "timestamp": datetime.now().isoformat()
            }
        
        # Process tool calls
        if response.stop_reason == "tool_use":
            # Add assistant response to messages
            messages.append({"role": "assistant", "content": response.content})
            
            # Process each tool call
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    tool_result = process_tool_call(block.name, block.input)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": tool_result
                    })
            
            # Add tool results to messages
            messages.append({"role": "user", "content": tool_results})
        else:
            break
    
    return {
        "status": "error",
        "message": "Agent did not complete within max iterations",
        "student_id": student_data.get('student_id')
    }

def batch_analyze_students(students: list) -> list:
    """Analyze multiple students and generate recommendations"""
    results = []
    for student in students:
        result = run_agent(student)
        results.append(result)
    return results

if __name__ == "__main__":
    # Example usage
    sample_student = {
        "student_id": "S-001",
        "attendance": 75,
        "grade_average": 68,
        "time_on_task": 35,
        "lms_logins_per_week": 1.5,
        "missing_assignments": 3
    }
    
    print("Running LangGraph Agent Analysis...")
    result = run_agent(sample_student)
    print(json.dumps(result, indent=2))
