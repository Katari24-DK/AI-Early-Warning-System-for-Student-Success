"""
Integration between Data Pipeline and FastAPI Backend
"""

from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from data_pipeline import pipeline
import json

router = APIRouter(prefix="/api/database", tags=["database"])

class StudentRecord(BaseModel):
    student_id: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[str] = None
    major: Optional[str] = None
    attendance: float
    grade_average: float
    time_on_task: float
    lms_logins_per_week: float
    missing_assignments: int
    prior_risk_flag: int

@router.post("/initialize")
async def initialize_database():
    """Initialize database schema"""
    try:
        pipeline.connect()
        result = pipeline.initialize_database()
        pipeline.disconnect()
        return {"status": "success" if result else "error"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/insert-student")
async def insert_student(record: StudentRecord):
    """Insert or update student record"""
    try:
        pipeline.connect()
        
        # Insert student
        pipeline.insert_student(
            record.student_id,
            record.first_name,
            record.last_name,
            record.email,
            record.major
        )
        
        # Insert metrics
        pipeline.insert_metrics(
            record.student_id,
            record.attendance,
            record.grade_average,
            record.time_on_task,
            record.lms_logins_per_week,
            record.missing_assignments,
            record.prior_risk_flag
        )
        
        pipeline.disconnect()
        return {"status": "success", "student_id": record.student_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/upload-csv")
async def upload_csv(file: UploadFile = File(...)):
    """Upload and process CSV file"""
    try:
        # Save file temporarily
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
            contents = await file.read()
            tmp.write(contents)
            tmp_path = tmp.name
        
        # Process file
        pipeline.connect()
        result = pipeline.load_csv(tmp_path)
        pipeline.disconnect()
        
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/students")
async def get_all_students():
    """Get all students"""
    try:
        pipeline.connect()
        students = pipeline.get_all_students()
        pipeline.disconnect()
        return {"students": students, "total": len(students)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/student/{student_id}/history")
async def get_student_history(student_id: str, limit: int = 10):
    """Get student metrics history"""
    try:
        pipeline.connect()
        history = pipeline.get_student_history(student_id, limit)
        pipeline.disconnect()
        return {"student_id": student_id, "history": history}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/statistics")
async def get_statistics():
    """Get database statistics"""
    try:
        pipeline.connect()
        stats = pipeline.get_statistics()
        pipeline.disconnect()
        return stats
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/log-activity")
async def log_activity(message: str, activity_type: str, user_id: Optional[str] = None):
    """Log activity"""
    try:
        pipeline.connect()
        pipeline.log_activity(message, activity_type, user_id)
        pipeline.disconnect()
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/health")
async def database_health():
    """Check database health"""
    try:
        pipeline.connect()
        stats = pipeline.get_statistics()
        pipeline.disconnect()
        return {
            "status": "healthy",
            "service": "Database Pipeline",
            "statistics": stats
        }
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
