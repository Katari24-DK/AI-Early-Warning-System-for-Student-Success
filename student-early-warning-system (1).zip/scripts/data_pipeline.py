"""
Data Pipeline for Student Early Warning System
Handles data ingestion, validation, cleaning, and transformation
"""

import sqlite3
import pandas as pd
import csv
import json
from datetime import datetime
from typing import List, Dict, Tuple, Optional
from pathlib import Path
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataPipeline:
    """Main data pipeline for managing student data"""
    
    def __init__(self, db_path: str = "student_data.db"):
        self.db_path = db_path
        self.connection = None
        self.cursor = None
        self.validation_errors = []
        self.processed_records = 0
        
    def connect(self) -> bool:
        """Connect to database"""
        try:
            self.connection = sqlite3.connect(self.db_path)
            self.cursor = self.connection.cursor()
            logger.info(f"Connected to database: {self.db_path}")
            return True
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from database"""
        if self.connection:
            self.connection.close()
            logger.info("Disconnected from database")
    
    def initialize_database(self, schema_path: str = "database_schema.sql") -> bool:
        """Initialize database with schema"""
        try:
            with open(schema_path, 'r') as f:
                schema = f.read()
            
            self.cursor.executescript(schema)
            self.connection.commit()
            logger.info("Database schema initialized")
            return True
        except Exception as e:
            logger.error(f"Schema initialization failed: {e}")
            return False
    
    def validate_student_record(self, record: Dict) -> Tuple[bool, List[str]]:
        """Validate a student record"""
        errors = []
        
        # Required fields
        if not record.get('student_id'):
            errors.append("Missing student_id")
        
        # Validate numeric fields
        try:
            attendance = float(record.get('attendance', 0))
            if not (0 <= attendance <= 100):
                errors.append("Attendance must be between 0 and 100")
        except ValueError:
            errors.append("Attendance must be numeric")
        
        try:
            grade_average = float(record.get('grade_average', 0))
            if not (0 <= grade_average <= 100):
                errors.append("Grade average must be between 0 and 100")
        except ValueError:
            errors.append("Grade average must be numeric")
        
        try:
            time_on_task = float(record.get('time_on_task', 0))
            if time_on_task < 0:
                errors.append("Time on task cannot be negative")
        except ValueError:
            errors.append("Time on task must be numeric")
        
        try:
            lms_logins = float(record.get('lms_logins_per_week', 0))
            if lms_logins < 0:
                errors.append("LMS logins cannot be negative")
        except ValueError:
            errors.append("LMS logins must be numeric")
        
        try:
            missing_assignments = int(record.get('missing_assignments', 0))
            if missing_assignments < 0:
                errors.append("Missing assignments cannot be negative")
        except ValueError:
            errors.append("Missing assignments must be integer")
        
        return len(errors) == 0, errors
    
    def insert_student(self, student_id: str, first_name: str = None, 
                      last_name: str = None, email: str = None, 
                      major: str = None) -> bool:
        """Insert or update student record"""
        try:
            self.cursor.execute("""
                INSERT OR REPLACE INTO students 
                (student_id, first_name, last_name, email, major, updated_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (student_id, first_name, last_name, email, major))
            self.connection.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to insert student: {e}")
            return False
    
    def insert_metrics(self, student_id: str, attendance: float, 
                      grade_average: float, time_on_task: float,
                      lms_logins_per_week: float, missing_assignments: int,
                      prior_risk_flag: int, recorded_date: str = None) -> bool:
        """Insert student metrics"""
        try:
            if recorded_date is None:
                recorded_date = datetime.now().date()
            
            self.cursor.execute("""
                INSERT INTO student_metrics
                (student_id, attendance, grade_average, time_on_task, 
                 lms_logins_per_week, missing_assignments, prior_risk_flag, recorded_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (student_id, attendance, grade_average, time_on_task,
                  lms_logins_per_week, missing_assignments, prior_risk_flag, recorded_date))
            self.connection.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to insert metrics: {e}")
            return False
    
    def insert_prediction(self, student_id: str, model_name: str, 
                         risk_score: float, at_risk: bool, 
                         confidence: float) -> bool:
        """Insert risk prediction"""
        try:
            self.cursor.execute("""
                INSERT INTO risk_predictions
                (student_id, model_name, risk_score, at_risk, confidence, prediction_date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (student_id, model_name, risk_score, at_risk, confidence, datetime.now().date()))
            self.connection.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to insert prediction: {e}")
            return False
    
    def insert_alert(self, alert_id: str, student_id: str, severity: str,
                    message: str, intervention: str) -> bool:
        """Insert alert"""
        try:
            self.cursor.execute("""
                INSERT INTO alerts
                (alert_id, student_id, severity, message, intervention)
                VALUES (?, ?, ?, ?, ?)
            """, (alert_id, student_id, severity, message, intervention))
            self.connection.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to insert alert: {e}")
            return False
    
    def insert_intervention(self, intervention_id: str, student_id: str,
                           intervention_type: str, description: str,
                           assigned_to: str = None, due_date: str = None) -> bool:
        """Insert intervention"""
        try:
            self.cursor.execute("""
                INSERT INTO interventions
                (intervention_id, student_id, intervention_type, description, 
                 status, assigned_to, due_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (intervention_id, student_id, intervention_type, description,
                  'pending', assigned_to, due_date))
            self.connection.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to insert intervention: {e}")
            return False
    
    def log_activity(self, message: str, activity_type: str, 
                    user_id: str = None, details: str = None) -> bool:
        """Log activity"""
        try:
            self.cursor.execute("""
                INSERT INTO activity_log
                (message, activity_type, user_id, details)
                VALUES (?, ?, ?, ?)
            """, (message, activity_type, user_id, details))
            self.connection.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to log activity: {e}")
            return False
    
    def load_csv(self, filepath: str) -> Dict:
        """Load and process CSV file"""
        self.validation_errors = []
        self.processed_records = 0
        
        try:
            df = pd.read_csv(filepath)
            
            for idx, row in df.iterrows():
                record = row.to_dict()
                
                # Validate record
                is_valid, errors = self.validate_student_record(record)
                
                if not is_valid:
                    self.validation_errors.append({
                        "row": idx + 2,
                        "student_id": record.get('student_id'),
                        "errors": errors
                    })
                    continue
                
                # Insert student
                self.insert_student(
                    record.get('student_id'),
                    record.get('first_name'),
                    record.get('last_name'),
                    record.get('email'),
                    record.get('major')
                )
                
                # Insert metrics
                self.insert_metrics(
                    record.get('student_id'),
                    float(record.get('attendance', 0)),
                    float(record.get('grade_average', 0)),
                    float(record.get('time_on_task', 0)),
                    float(record.get('lms_logins_per_week', 0)),
                    int(record.get('missing_assignments', 0)),
                    int(record.get('prior_risk_flag', 0))
                )
                
                self.processed_records += 1
            
            # Log activity
            self.log_activity(
                f"Loaded {self.processed_records} records from {filepath}",
                "data_import",
                details=json.dumps({"file": filepath, "total_rows": len(df)})
            )
            
            return {
                "status": "success",
                "file": filepath,
                "total_rows": len(df),
                "processed": self.processed_records,
                "errors": len(self.validation_errors),
                "validation_errors": self.validation_errors
            }
        except Exception as e:
            logger.error(f"Failed to load CSV: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def get_student_history(self, student_id: str, limit: int = 10) -> List[Dict]:
        """Get student metrics history"""
        try:
            self.cursor.execute("""
                SELECT * FROM student_metrics 
                WHERE student_id = ? 
                ORDER BY recorded_date DESC 
                LIMIT ?
            """, (student_id, limit))
            
            columns = [description[0] for description in self.cursor.description]
            results = []
            for row in self.cursor.fetchall():
                results.append(dict(zip(columns, row)))
            
            return results
        except Exception as e:
            logger.error(f"Failed to get student history: {e}")
            return []
    
    def get_all_students(self) -> List[Dict]:
        """Get all students"""
        try:
            self.cursor.execute("SELECT * FROM students")
            columns = [description[0] for description in self.cursor.description]
            results = []
            for row in self.cursor.fetchall():
                results.append(dict(zip(columns, row)))
            return results
        except Exception as e:
            logger.error(f"Failed to get students: {e}")
            return []
    
    def get_statistics(self) -> Dict:
        """Get database statistics"""
        try:
            self.cursor.execute("SELECT COUNT(*) FROM students")
            total_students = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT COUNT(*) FROM alerts WHERE acknowledged = FALSE")
            active_alerts = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT COUNT(*) FROM interventions WHERE status = 'pending'")
            pending_interventions = self.cursor.fetchone()[0]
            
            return {
                "total_students": total_students,
                "active_alerts": active_alerts,
                "pending_interventions": pending_interventions,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}")
            return {}

# Global pipeline instance
pipeline = DataPipeline()

if __name__ == "__main__":
    # Example usage
    print("Initializing data pipeline...")
    pipeline.connect()
    pipeline.initialize_database()
    
    print("Pipeline ready for data ingestion")
    pipeline.disconnect()
