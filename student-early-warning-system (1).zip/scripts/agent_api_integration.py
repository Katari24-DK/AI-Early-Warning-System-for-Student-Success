"""
Integration between LangGraph Agent and FastAPI Backend
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from langgraph_agent import run_agent, batch_analyze_students
import json

router = APIRouter(prefix="/api/agent", tags=["agent"])

class StudentAnalysisRequest(BaseModel):
    student_id: str
    attendance: float
    grade_average: float
    time_on_task: float
    lms_logins_per_week: float
    missing_assignments: int

class BatchAnalysisRequest(BaseModel):
    students: List[StudentAnalysisRequest]

@router.post("/analyze")
async def analyze_student(request: StudentAnalysisRequest):
    """Run agent analysis on a single student"""
    try:
        student_data = request.dict()
        result = run_agent(student_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/batch-analyze")
async def batch_analyze(request: BatchAnalysisRequest):
    """Run agent analysis on multiple students"""
    try:
        students = [s.dict() for s in request.students]
        results = batch_analyze_students(students)
        return {
            "total": len(results),
            "results": results,
            "status": "success"
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/health")
async def agent_health():
    """Check agent system health"""
    return {
        "status": "healthy",
        "service": "LangGraph Agent System",
        "version": "1.0.0"
    }
