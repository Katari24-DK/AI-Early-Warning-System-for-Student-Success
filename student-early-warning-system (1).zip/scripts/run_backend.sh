#!/bin/bash

# Install dependencies
pip install -r requirements.txt

# Run the FastAPI backend
python backend_main.py
