"""
FastAPI Backend for AI Early Warning System for Student Success
Handles data management, predictions, alerts, and interventions
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import json
import csv
import io
from datetime import datetime
import random

# Initialize FastAPI app
app = FastAPI(title="Student Success API", version="1.0.0")

# Add CORS middleware to allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage (replace with database in production)
student_data = {}
predictions_cache = {}
alerts_cache = []
activity_log = []
settings = {
    "risk_threshold": 0.6,
    "model": "xgboost",
    "alert_enabled": True,
}

# Pydantic models
class StudentRecord(BaseModel):
    student_id: str
    attendance: float
    grade_average: float
    time_on_task: float
    lms_logins_per_week: float
    missing_assignments: int
    prior_risk_flag: int

class PredictionRequest(BaseModel):
    risk_threshold: float = 0.6

class AlertResponse(BaseModel):
    student_id: str
    severity: str
    message: str
    intervention: str

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Data endpoints
@app.post("/api/analyze-student")
async def analyze_student(record: StudentRecord):
    """Analyze a single student record and calculate risk score"""
    try:
        # Simple risk calculation (replace with actual ML model)
        risk_score = calculate_risk_score(record)
        
        # Store student data
        student_data[record.student_id] = {
            "data": record.dict(),
            "risk_score": risk_score,
            "timestamp": datetime.now().isoformat(),
        }
        
        # Log activity
        log_activity(f"Analyzed student {record.student_id}", "analysis")
        
        return {
            "student_id": record.student_id,
            "risk_score": risk_score,
            "status": "success",
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/upload-csv")
async def upload_csv(file: UploadFile = File(...)):
    """Upload and process CSV file with student records"""
    try:
        contents = await file.read()
        stream = io.StringIO(contents.decode("utf8"))
        csv_reader = csv.DictReader(stream)
        
        records_processed = 0
        for row in csv_reader:
            try:
                record = StudentRecord(
                    student_id=row.get("student_id", f"S-{records_processed}"),
                    attendance=float(row.get("attendance", 80)),
                    grade_average=float(row.get("grade_average", 75)),
                    time_on_task=float(row.get("time_on_task", 50)),
                    lms_logins_per_week=float(row.get("lms_logins_per_week", 1)),
                    missing_assignments=int(row.get("missing_assignments", 0)),
                    prior_risk_flag=int(row.get("prior_risk_flag", 0)),
                )
                
                risk_score = calculate_risk_score(record)
                student_data[record.student_id] = {
                    "data": record.dict(),
                    "risk_score": risk_score,
                    "timestamp": datetime.now().isoformat(),
                }
                records_processed += 1
            except Exception as e:
                print(f"Error processing row: {e}")
                continue
        
        log_activity(f"Uploaded {records_processed} student records", "upload")
        
        return {
            "records_processed": records_processed,
            "status": "success",
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/students")
async def get_students():
    """Get all student records"""
    return {
        "students": list(student_data.values()),
        "total": len(student_data),
    }

# Prediction endpoints
@app.post("/api/predict-all")
async def predict_all(request: PredictionRequest):
    """Run predictions on all students"""
    try:
        predictions = []
        for student_id, student_info in student_data.items():
            risk_score = student_info.get("risk_score", 0)
            predictions.append({
                "student_id": student_id,
                "risk_score": risk_score,
                "at_risk": risk_score > request.risk_threshold,
            })
        
        predictions_cache["latest"] = {
            "predictions": predictions,
            "threshold": request.risk_threshold,
            "timestamp": datetime.now().isoformat(),
        }
        
        # Generate alerts for at-risk students
        generate_alerts(predictions, request.risk_threshold)
        
        log_activity(f"Generated predictions for {len(predictions)} students", "prediction")
        
        return {
            "predictions": predictions,
            "total": len(predictions),
            "at_risk_count": sum(1 for p in predictions if p["at_risk"]),
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Alert endpoints
@app.get("/api/alerts")
async def get_alerts():
    """Get all active alerts"""
    return {
        "alerts": alerts_cache,
        "total": len(alerts_cache),
    }

@app.post("/api/alerts/acknowledge")
async def acknowledge_alert(alert_id: str):
    """Acknowledge an alert"""
    try:
        for alert in alerts_cache:
            if alert.get("id") == alert_id:
                alert["acknowledged"] = True
                alert["acknowledged_at"] = datetime.now().isoformat()
                log_activity(f"Acknowledged alert {alert_id}", "alert")
                return {"status": "success"}
        
        raise HTTPException(status_code=404, detail="Alert not found")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Settings endpoints
@app.get("/api/settings")
async def get_settings():
    """Get system settings"""
    return settings

@app.post("/api/settings")
async def update_settings(new_settings: dict):
    """Update system settings"""
    try:
        settings.update(new_settings)
        log_activity("Updated system settings", "settings")
        return {"status": "success", "settings": settings}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Activity log endpoints
@app.get("/api/activity-log")
async def get_activity_log(limit: int = 100):
    """Get activity log"""
    return {
        "activities": activity_log[-limit:],
        "total": len(activity_log),
    }

# File management endpoints
@app.get("/api/files")
async def get_files():
    """Get list of uploaded files"""
    return {
        "files": [
            {
                "name": "students_batch_1.csv",
                "size": 1024,
                "uploaded_at": "2024-01-15T10:30:00",
                "records": 150,
            },
            {
                "name": "students_batch_2.csv",
                "size": 2048,
                "uploaded_at": "2024-01-16T14:20:00",
                "records": 200,
            },
        ],
        "total": 2,
    }

# Helper functions
def calculate_risk_score(record: StudentRecord) -> float:
    """
    Calculate risk score based on student metrics
    Returns a score between 0 and 1
    """
    risk_score = 0.0
    
    # Attendance factor (lower attendance = higher risk)
    if record.attendance < 80:
        risk_score += (80 - record.attendance) / 100 * 0.3
    
    # Grade factor (lower grades = higher risk)
    if record.grade_average < 70:
        risk_score += (70 - record.grade_average) / 100 * 0.3
    
    # Time on task factor
    if record.time_on_task < 40:
        risk_score += (40 - record.time_on_task) / 100 * 0.2
    
    # LMS engagement factor
    if record.lms_logins_per_week < 2:
        risk_score += (2 - record.lms_logins_per_week) / 2 * 0.1
    
    # Missing assignments factor
    if record.missing_assignments > 2:
        risk_score += min(record.missing_assignments / 10, 0.1)
    
    # Prior risk flag
    if record.prior_risk_flag == 1:
        risk_score += 0.1
    
    return min(risk_score, 1.0)

def generate_alerts(predictions: List[dict], threshold: float):
    """Generate alerts for at-risk students"""
    global alerts_cache
    alerts_cache = []
    
    interventions = [
        "Schedule one-on-one meeting with student",
        "Recommend tutoring services",
        "Increase check-in frequency",
        "Refer to academic advisor",
        "Suggest study group participation",
    ]
    
    for prediction in predictions:
        if prediction["at_risk"]:
            risk_score = prediction["risk_score"]
            
            # Determine severity
            if risk_score > 0.8:
                severity = "critical"
            elif risk_score > 0.7:
                severity = "warning"
            else:
                severity = "info"
            
            alert = {
                "id": f"alert_{prediction['student_id']}_{datetime.now().timestamp()}",
                "student_id": prediction["student_id"],
                "severity": severity,
                "message": f"Student at risk with score {risk_score:.2%}",
                "intervention": random.choice(interventions),
                "created_at": datetime.now().isoformat(),
                "acknowledged": False,
            }
            alerts_cache.append(alert)

def log_activity(message: str, activity_type: str):
    """Log activity to activity log"""
    activity = {
        "message": message,
        "type": activity_type,
        "timestamp": datetime.now().isoformat(),
    }
    activity_log.append(activity)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
