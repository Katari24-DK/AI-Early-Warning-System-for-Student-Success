"""
Setup script for the Early Warning System
Creates sample student data for testing
"""

import pandas as pd
import numpy as np
from datetime import datetime

def create_sample_data():
    """Create sample student data"""
    np.random.seed(42)
    
    n_students = 100
    
    data = {
        'student_id': [f'S-{i:03d}' for i in range(1, n_students + 1)],
        'attendance': np.random.uniform(60, 100, n_students),
        'grade_average': np.random.uniform(50, 95, n_students),
        'time_on_task': np.random.uniform(20, 120, n_students),
        'lms_logins_per_week': np.random.uniform(0.5, 10, n_students),
        'missing_assignments': np.random.randint(0, 10, n_students),
        'prior_risk_flag': np.random.randint(0, 2, n_students)
    }
    
    df = pd.DataFrame(data)
    df.to_csv('sample_students.csv', index=False)
    print(f"Created sample_students.csv with {n_students} records")
    
    return df

if __name__ == "__main__":
    create_sample_data()
