"""
API endpoints for Alert and Intervention System
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from alert_system import orchestrator, alert_system, intervention_system
import json

router = APIRouter(prefix="/api/alerts-interventions", tags=["alerts-interventions"])

class ProcessRiskRequest(BaseModel):
    student_id: str
    risk_score: float
    attendance: float
    grade_average: float
    time_on_task: float
    lms_logins_per_week: float
    missing_assignments: int
    assigned_to: Optional[str] = None

class AcknowledgeAlertRequest(BaseModel):
    alert_id: str

class UpdateInterventionRequest(BaseModel):
    intervention_id: str
    status: str
    note: Optional[str] = None

@router.post("/process-risk")
async def process_risk(request: ProcessRiskRequest):
    """Process student risk and generate alert + intervention"""
    try:
        student_data = {
            "attendance": request.attendance,
            "grade_average": request.grade_average,
            "time_on_task": request.time_on_task,
            "lms_logins_per_week": request.lms_logins_per_week,
            "missing_assignments": request.missing_assignments
        }
        
        result = orchestrator.process_student_risk(
            request.student_id,
            request.risk_score,
            student_data,
            request.assigned_to
        )
        
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/active-alerts")
async def get_active_alerts():
    """Get all active alerts"""
    try:
        alerts = alert_system.get_active_alerts()
        return {
            "total": len(alerts),
            "alerts": alerts
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/student/{student_id}/alerts")
async def get_student_alerts(student_id: str):
    """Get alerts for specific student"""
    try:
        alerts = alert_system.get_student_alerts(student_id)
        return {
            "student_id": student_id,
            "total": len(alerts),
            "alerts": alerts
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/acknowledge-alert")
async def acknowledge_alert(request: AcknowledgeAlertRequest):
    """Acknowledge an alert"""
    try:
        success = alert_system.acknowledge_alert(request.alert_id)
        if not success:
            raise HTTPException(status_code=404, detail="Alert not found")
        return {"status": "success", "alert_id": request.alert_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/resolve-alert")
async def resolve_alert(request: AcknowledgeAlertRequest):
    """Resolve an alert"""
    try:
        success = alert_system.resolve_alert(request.alert_id)
        if not success:
            raise HTTPException(status_code=404, detail="Alert not found")
        return {"status": "success", "alert_id": request.alert_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/student/{student_id}/interventions")
async def get_student_interventions(student_id: str):
    """Get interventions for specific student"""
    try:
        interventions = intervention_system.get_student_interventions(student_id)
        return {
            "student_id": student_id,
            "total": len(interventions),
            "interventions": interventions
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/pending-interventions")
async def get_pending_interventions():
    """Get all pending interventions"""
    try:
        interventions = intervention_system.get_pending_interventions()
        return {
            "total": len(interventions),
            "interventions": interventions
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/overdue-interventions")
async def get_overdue_interventions():
    """Get overdue interventions"""
    try:
        interventions = intervention_system.get_overdue_interventions()
        return {
            "total": len(interventions),
            "interventions": interventions
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/update-intervention")
async def update_intervention(request: UpdateInterventionRequest):
    """Update intervention status"""
    try:
        success = intervention_system.update_intervention_status(
            request.intervention_id,
            request.status,
            request.note
        )
        if not success:
            raise HTTPException(status_code=404, detail="Intervention not found")
        return {"status": "success", "intervention_id": request.intervention_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/dashboard-summary")
async def get_dashboard_summary():
    """Get dashboard summary"""
    try:
        summary = orchestrator.get_dashboard_summary()
        return summary
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/resources/{intervention_type}")
async def get_resources(intervention_type: str):
    """Get resources for intervention type"""
    try:
        resources = intervention_system.get_resources(intervention_type)
        return {
            "intervention_type": intervention_type,
            "resources": resources
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/health")
async def alerts_health():
    """Check alert system health"""
    return {
        "status": "healthy",
        "service": "Alert and Intervention System",
        "version": "1.0.0"
    }
