"""
Integration between Predictive Models and FastAPI Backend
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from predictive_models import engine, generate_sample_training_data
import json

router = APIRouter(prefix="/api/models", tags=["models"])

class PredictionRequest(BaseModel):
    features: List[float]
    model_name: str = "xgboost"

class BatchPredictionRequest(BaseModel):
    records: List[dict]
    model_name: str = "xgboost"

class TrainingRequest(BaseModel):
    test_size: float = 0.2

@router.post("/initialize")
async def initialize_models():
    """Initialize all model types"""
    try:
        result = engine.create_models()
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/train")
async def train_models(request: TrainingRequest):
    """Train models on sample data"""
    try:
        # Generate training data
        training_data = generate_sample_training_data(500)
        
        # Prepare data
        X, y = engine.prepare_data(training_data)
        
        # Train models
        results = engine.train_models(X, y, test_size=request.test_size)
        return results
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/predict")
async def predict(request: PredictionRequest):
    """Make prediction using specified model"""
    try:
        result = engine.predict(request.features, request.model_name)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/predict-batch")
async def predict_batch(request: BatchPredictionRequest):
    """Make predictions for multiple students"""
    try:
        predictions = engine.predict_batch(request.records, request.model_name)
        return {
            "total": len(predictions),
            "predictions": predictions,
            "model": request.model_name
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/performance")
async def get_performance():
    """Get model performance metrics"""
    try:
        comparison = engine.get_model_comparison()
        return comparison
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/save")
async def save_models(filepath: str = "models/"):
    """Save trained models to disk"""
    try:
        result = engine.save_models(filepath)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/load")
async def load_models(filepath: str = "models/"):
    """Load trained models from disk"""
    try:
        result = engine.load_models(filepath)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/health")
async def models_health():
    """Check models system health"""
    return {
        "status": "healthy",
        "service": "Predictive Models Engine",
        "models_available": list(engine.models.keys()),
        "version": "1.0.0"
    }
