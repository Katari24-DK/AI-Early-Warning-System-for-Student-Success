"""
Alert System for Student Early Warning
Generates, manages, and tracks alerts for at-risk students
"""

import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from enum import Enum
import uuid

class AlertSeverity(Enum):
    """Alert severity levels"""
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"

class InterventionType(Enum):
    """Types of interventions"""
    ACADEMIC = "academic"
    ENGAGEMENT = "engagement"
    ATTENDANCE = "attendance"
    MENTAL_HEALTH = "mental_health"
    FINANCIAL = "financial"

class AlertSystem:
    """Manages alert generation and tracking"""
    
    def __init__(self):
        self.alerts = {}
        self.alert_history = []
        self.alert_rules = self._initialize_rules()
    
    def _initialize_rules(self) -> Dict:
        """Initialize alert generation rules"""
        return {
            "critical": {
                "risk_threshold": 0.8,
                "conditions": [
                    "attendance < 70",
                    "grade_average < 60",
                    "missing_assignments > 5"
                ]
            },
            "warning": {
                "risk_threshold": 0.6,
                "conditions": [
                    "attendance < 80",
                    "grade_average < 70",
                    "missing_assignments > 2"
                ]
            },
            "info": {
                "risk_threshold": 0.4,
                "conditions": [
                    "attendance < 85",
                    "grade_average < 75"
                ]
            }
        }
    
    def generate_alert(self, student_id: str, risk_score: float, 
                      student_data: Dict) -> Optional[Dict]:
        """Generate alert based on risk score and student data"""
        
        # Determine severity
        severity = self._determine_severity(risk_score, student_data)
        
        if severity is None:
            return None
        
        # Generate alert ID
        alert_id = f"alert_{student_id}_{uuid.uuid4().hex[:8]}"
        
        # Determine intervention type
        intervention_type = self._determine_intervention_type(student_data)
        
        # Generate message and intervention
        message = self._generate_message(severity, student_data)
        intervention = self._generate_intervention(intervention_type, student_data)
        
        alert = {
            "id": alert_id,
            "student_id": student_id,
            "severity": severity,
            "risk_score": risk_score,
            "message": message,
            "intervention": intervention,
            "intervention_type": intervention_type,
            "created_at": datetime.now().isoformat(),
            "acknowledged": False,
            "acknowledged_at": None,
            "resolved": False,
            "resolved_at": None
        }
        
        # Store alert
        self.alerts[alert_id] = alert
        self.alert_history.append(alert)
        
        return alert
    
    def _determine_severity(self, risk_score: float, student_data: Dict) -> Optional[str]:
        """Determine alert severity based on risk score and conditions"""
        
        if risk_score >= 0.8:
            return AlertSeverity.CRITICAL.value
        elif risk_score >= 0.6:
            return AlertSeverity.WARNING.value
        elif risk_score >= 0.4:
            return AlertSeverity.INFO.value
        
        return None
    
    def _determine_intervention_type(self, student_data: Dict) -> str:
        """Determine appropriate intervention type"""
        
        attendance = student_data.get('attendance', 100)
        grade_average = student_data.get('grade_average', 100)
        time_on_task = student_data.get('time_on_task', 100)
        lms_logins = student_data.get('lms_logins_per_week', 5)
        missing_assignments = student_data.get('missing_assignments', 0)
        
        # Priority-based intervention selection
        if attendance < 75:
            return InterventionType.ATTENDANCE.value
        elif grade_average < 65:
            return InterventionType.ACADEMIC.value
        elif missing_assignments > 3:
            return InterventionType.ACADEMIC.value
        elif lms_logins < 1.5 or time_on_task < 30:
            return InterventionType.ENGAGEMENT.value
        else:
            return InterventionType.MENTAL_HEALTH.value
    
    def _generate_message(self, severity: str, student_data: Dict) -> str:
        """Generate alert message"""
        
        messages = {
            "critical": f"CRITICAL: Student is at high risk of academic failure. "
                        f"Immediate intervention required.",
            "warning": f"WARNING: Student shows signs of academic struggle. "
                       f"Proactive support recommended.",
            "info": f"INFO: Student may benefit from additional support. "
                   f"Monitor progress closely."
        }
        
        return messages.get(severity, "Alert generated for student")
    
    def _generate_intervention(self, intervention_type: str, student_data: Dict) -> str:
        """Generate intervention recommendation"""
        
        interventions = {
            InterventionType.ACADEMIC.value: "Schedule tutoring session and review study strategies",
            InterventionType.ENGAGEMENT.value: "Encourage participation in study groups and office hours",
            InterventionType.ATTENDANCE.value: "Discuss attendance barriers and create attendance plan",
            InterventionType.MENTAL_HEALTH.value: "Refer to counseling services and wellness resources",
            InterventionType.FINANCIAL.value: "Connect with financial aid office for support options"
        }
        
        return interventions.get(intervention_type, "Provide academic support")
    
    def acknowledge_alert(self, alert_id: str) -> bool:
        """Acknowledge an alert"""
        if alert_id in self.alerts:
            self.alerts[alert_id]["acknowledged"] = True
            self.alerts[alert_id]["acknowledged_at"] = datetime.now().isoformat()
            return True
        return False
    
    def resolve_alert(self, alert_id: str) -> bool:
        """Resolve an alert"""
        if alert_id in self.alerts:
            self.alerts[alert_id]["resolved"] = True
            self.alerts[alert_id]["resolved_at"] = datetime.now().isoformat()
            return True
        return False
    
    def get_active_alerts(self) -> List[Dict]:
        """Get all active (unresolved) alerts"""
        return [alert for alert in self.alerts.values() if not alert["resolved"]]
    
    def get_student_alerts(self, student_id: str) -> List[Dict]:
        """Get all alerts for a specific student"""
        return [alert for alert in self.alerts.values() if alert["student_id"] == student_id]
    
    def get_alerts_by_severity(self, severity: str) -> List[Dict]:
        """Get alerts by severity level"""
        return [alert for alert in self.alerts.values() if alert["severity"] == severity]

class InterventionSystem:
    """Manages intervention recommendations and tracking"""
    
    def __init__(self):
        self.interventions = {}
        self.intervention_history = []
        self.resources = self._initialize_resources()
    
    def _initialize_resources(self) -> Dict:
        """Initialize intervention resources"""
        return {
            InterventionType.ACADEMIC.value: [
                "Tutoring Center - Available Mon-Fri 9am-5pm",
                "Writing Center - Drop-in support for essays",
                "Study Skills Workshop - Thursdays at 3pm",
                "Peer Tutoring Program - Free one-on-one sessions"
            ],
            InterventionType.ENGAGEMENT.value: [
                "Study Groups - Join existing groups or create new ones",
                "Learning Communities - Connect with peers in your major",
                "Online Discussion Forums - Engage with classmates",
                "Office Hours - Meet with instructors regularly"
            ],
            InterventionType.ATTENDANCE.value: [
                "Attendance Support Program - Help with barriers",
                "Transportation Assistance - Available for eligible students",
                "Childcare Resources - On-campus and partner facilities",
                "Health Services - Address health-related absences"
            ],
            InterventionType.MENTAL_HEALTH.value: [
                "Counseling Services - Free confidential counseling",
                "Peer Support Groups - Connect with others",
                "Stress Management Workshops - Learn coping strategies",
                "Crisis Hotline - 24/7 support available"
            ],
            InterventionType.FINANCIAL.value: [
                "Financial Aid Office - Review funding options",
                "Emergency Grants - Available for eligible students",
                "Work-Study Program - On-campus employment",
                "Scholarship Opportunities - Additional funding sources"
            ]
        }
    
    def create_intervention(self, student_id: str, intervention_type: str,
                           description: str, assigned_to: str = None,
                           due_date: str = None) -> Dict:
        """Create intervention plan"""
        
        intervention_id = f"int_{student_id}_{uuid.uuid4().hex[:8]}"
        
        intervention = {
            "id": intervention_id,
            "student_id": student_id,
            "type": intervention_type,
            "description": description,
            "status": "pending",
            "assigned_to": assigned_to,
            "due_date": due_date,
            "resources": self.resources.get(intervention_type, []),
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "completed_at": None,
            "notes": []
        }
        
        self.interventions[intervention_id] = intervention
        self.intervention_history.append(intervention)
        
        return intervention
    
    def update_intervention_status(self, intervention_id: str, status: str,
                                  note: str = None) -> bool:
        """Update intervention status"""
        
        if intervention_id not in self.interventions:
            return False
        
        intervention = self.interventions[intervention_id]
        intervention["status"] = status
        intervention["updated_at"] = datetime.now().isoformat()
        
        if status == "completed":
            intervention["completed_at"] = datetime.now().isoformat()
        
        if note:
            intervention["notes"].append({
                "timestamp": datetime.now().isoformat(),
                "note": note
            })
        
        return True
    
    def get_student_interventions(self, student_id: str) -> List[Dict]:
        """Get all interventions for a student"""
        return [i for i in self.interventions.values() if i["student_id"] == student_id]
    
    def get_pending_interventions(self) -> List[Dict]:
        """Get all pending interventions"""
        return [i for i in self.interventions.values() if i["status"] == "pending"]
    
    def get_overdue_interventions(self) -> List[Dict]:
        """Get overdue interventions"""
        overdue = []
        today = datetime.now().date()
        
        for intervention in self.interventions.values():
            if intervention["status"] != "completed" and intervention["due_date"]:
                due_date = datetime.fromisoformat(intervention["due_date"]).date()
                if due_date < today:
                    overdue.append(intervention)
        
        return overdue
    
    def get_resources(self, intervention_type: str) -> List[str]:
        """Get resources for intervention type"""
        return self.resources.get(intervention_type, [])

class AlertInterventionOrchestrator:
    """Orchestrates alert generation and intervention assignment"""
    
    def __init__(self):
        self.alert_system = AlertSystem()
        self.intervention_system = InterventionSystem()
    
    def process_student_risk(self, student_id: str, risk_score: float,
                            student_data: Dict, assigned_to: str = None) -> Dict:
        """Process student risk and generate alert + intervention"""
        
        # Generate alert
        alert = self.alert_system.generate_alert(student_id, risk_score, student_data)
        
        if alert is None:
            return {"status": "no_alert", "student_id": student_id}
        
        # Create intervention
        intervention = self.intervention_system.create_intervention(
            student_id=student_id,
            intervention_type=alert["intervention_type"],
            description=alert["intervention"],
            assigned_to=assigned_to,
            due_date=(datetime.now() + timedelta(days=7)).isoformat()
        )
        
        return {
            "status": "success",
            "student_id": student_id,
            "alert": alert,
            "intervention": intervention
        }
    
    def get_dashboard_summary(self) -> Dict:
        """Get summary for dashboard"""
        
        active_alerts = self.alert_system.get_active_alerts()
        critical_alerts = self.alert_system.get_alerts_by_severity("critical")
        warning_alerts = self.alert_system.get_alerts_by_severity("warning")
        pending_interventions = self.intervention_system.get_pending_interventions()
        overdue_interventions = self.intervention_system.get_overdue_interventions()
        
        return {
            "total_active_alerts": len(active_alerts),
            "critical_alerts": len(critical_alerts),
            "warning_alerts": len(warning_alerts),
            "info_alerts": len(active_alerts) - len(critical_alerts) - len(warning_alerts),
            "pending_interventions": len(pending_interventions),
            "overdue_interventions": len(overdue_interventions),
            "timestamp": datetime.now().isoformat()
        }

# Global instances
alert_system = AlertSystem()
intervention_system = InterventionSystem()
orchestrator = AlertInterventionOrchestrator()

if __name__ == "__main__":
    # Example usage
    print("Testing Alert and Intervention System...")
    
    sample_student = {
        "attendance": 72,
        "grade_average": 65,
        "time_on_task": 35,
        "lms_logins_per_week": 1.2,
        "missing_assignments": 4
    }
    
    result = orchestrator.process_student_risk(
        "S-001",
        0.75,
        sample_student,
        "Dr. Smith"
    )
    
    print(json.dumps(result, indent=2))
