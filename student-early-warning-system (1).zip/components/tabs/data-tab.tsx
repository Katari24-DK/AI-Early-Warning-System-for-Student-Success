"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, Plus } from "lucide-react"

interface DataTabProps {
  apiUrl: string
  riskThreshold: number
}

export default function DataTab({ apiUrl, riskThreshold }: DataTabProps) {
  const [studentId, setStudentId] = useState("221FA04324")
  const [attendance, setAttendance] = useState([82])
  const [gradeAverage, setGradeAverage] = useState("72.00")
  const [timeOnTask, setTimeOnTask] = useState("55.00")
  const [lmsLogins, setLmsLogins] = useState("1.00")
  const [missingAssignments, setMissingAssignments] = useState("2")
  const [priorRiskFlag, setPriorRiskFlag] = useState("0")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${apiUrl}/api/analyze-student`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          student_id: studentId,
          attendance: attendance[0],
          grade_average: Number.parseFloat(gradeAverage),
          time_on_task: Number.parseFloat(timeOnTask),
          lms_logins_per_week: Number.parseFloat(lmsLogins),
          missing_assignments: Number.parseInt(missingAssignments),
          prior_risk_flag: Number.parseInt(priorRiskFlag),
        }),
      })
      const data = await response.json()
      alert(`Analysis complete! Risk Score: ${data.risk_score?.toFixed(3) || "N/A"}`)
    } catch (error) {
      alert("Error analyzing student: " + error)
    } finally {
      setLoading(false)
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    const formData = new FormData()
    formData.append("file", file)

    try {
      const response = await fetch(`${apiUrl}/api/upload-csv`, {
        method: "POST",
        body: formData,
      })
      const data = await response.json()
      alert(`Uploaded ${data.records_processed || 0} student records`)
    } catch (error) {
      alert("Error uploading file: " + error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Student Data</CardTitle>
          <CardDescription>Upload CSV of student records</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* File Upload */}
            <div className="rounded-lg border-2 border-dashed border-border bg-muted/50 p-8 text-center">
              <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-2 font-medium">Drag and drop file here</p>
              <p className="text-sm text-muted-foreground">Limit 200MB per file • CSV</p>
              <input type="file" accept=".csv" onChange={handleFileUpload} className="mt-4 hidden" id="file-upload" />
              <Button
                onClick={() => document.getElementById("file-upload")?.click()}
                variant="default"
                className="mt-4"
                disabled={loading}
              >
                Browse Files
              </Button>
            </div>

            {/* Or Divider */}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="bg-background px-2 text-muted-foreground">Or enter a single student record:</span>
              </div>
            </div>

            {/* Single Student Form */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">Student ID</label>
                <Input
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  placeholder="e.g., 221FA04324"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Attendance (%)</label>
                <div className="space-y-2">
                  <Slider value={attendance} onValueChange={setAttendance} min={50} max={100} step={1} />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>50</span>
                    <span className="font-semibold text-foreground">{attendance[0]}</span>
                    <span>100</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Grade Average</label>
                <Input value={gradeAverage} onChange={(e) => setGradeAverage(e.target.value)} type="number" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Time on Task (min)</label>
                <Input value={timeOnTask} onChange={(e) => setTimeOnTask(e.target.value)} type="number" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">LMS Logins / week</label>
                <Input value={lmsLogins} onChange={(e) => setLmsLogins(e.target.value)} type="number" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Missing Assignments</label>
                <Input
                  value={missingAssignments}
                  onChange={(e) => setMissingAssignments(e.target.value)}
                  type="number"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Prior Risk Flag</label>
                <Select value={priorRiskFlag} onValueChange={setPriorRiskFlag}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">No</SelectItem>
                    <SelectItem value="1">Yes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button onClick={handleSubmit} className="w-full" disabled={loading}>
              <Plus className="mr-2 h-4 w-4" />
              {loading ? "Analyzing..." : "Add to Data Table"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
