"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface PredictTabProps {
  apiUrl: string
  riskThreshold: number
}

export default function PredictTab({ apiUrl, riskThreshold }: PredictTabProps) {
  const [predictions, setPredictions] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const handlePredictAll = async () => {
    setLoading(true)
    try {
      const response = await fetch(`${apiUrl}/api/predict-all`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ risk_threshold: riskThreshold }),
      })
      const data = await response.json()
      setPredictions(data.predictions || [])
    } catch (error) {
      alert("Error getting predictions: " + error)
    } finally {
      setLoading(false)
    }
  }

  const riskDistribution = predictions.reduce(
    (acc, p) => {
      const riskLevel = p.risk_score > riskThreshold ? "At Risk" : "Safe"
      const existing = acc.find((item) => item.name === riskLevel)
      if (existing) {
        existing.count += 1
      } else {
        acc.push({ name: riskLevel, count: 1 })
      }
      return acc
    },
    [] as Array<{ name: string; count: number }>,
  )

  const topRiskStudents = predictions.sort((a, b) => b.risk_score - a.risk_score).slice(0, 10)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Predictions</CardTitle>
          <CardDescription>Run predictions on all students</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={handlePredictAll} disabled={loading} className="w-full">
            {loading ? "Running Predictions..." : "Run Predictions"}
          </Button>
        </CardContent>
      </Card>

      {predictions.length > 0 && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Risk Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={riskDistribution}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="hsl(var(--chart-1))" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Top 10 At-Risk Students</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {topRiskStudents.map((student) => (
                  <div key={student.student_id} className="flex items-center justify-between rounded-lg border p-3">
                    <span className="font-medium">{student.student_id}</span>
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-32 rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-destructive"
                          style={{ width: `${student.risk_score * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-semibold">{(student.risk_score * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
