"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useState, useEffect } from "react"

export default function ActivityLogTab() {
  const [activities, setActivities] = useState<any[]>([])

  useEffect(() => {
    const stored = localStorage.getItem("activityLog")
    if (stored) {
      setActivities(JSON.parse(stored))
    }
  }, [])

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Activity Log</CardTitle>
          <CardDescription>Recent system activities and predictions</CardDescription>
        </CardHeader>
        <CardContent>
          {activities.length === 0 ? (
            <p className="text-muted-foreground">No activities recorded yet</p>
          ) : (
            <div className="space-y-2">
              {activities.map((activity, idx) => (
                <div key={idx} className="flex items-center justify-between border-b py-2 text-sm">
                  <span>{activity.action}</span>
                  <span className="text-muted-foreground">{activity.timestamp}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
