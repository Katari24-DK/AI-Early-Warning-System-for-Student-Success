"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle, Clock, Zap } from "lucide-react"

interface AlertsTabProps {
  apiUrl: string
}

interface Alert {
  student_id: string
  severity: "critical" | "warning" | "info"
  message: string
  intervention: string
  risk_score?: number
  timestamp?: string
}

export default function AlertsTab({ apiUrl }: AlertsTabProps) {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [interventions, setInterventions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<"alerts" | "interventions">("alerts")
  const [acknowledgedAlerts, setAcknowledgedAlerts] = useState<Set<string>>(new Set())

  useEffect(() => {
    fetchAlerts()
    fetchInterventions()
    const interval = setInterval(() => {
      fetchAlerts()
      fetchInterventions()
    }, 30000)
    return () => clearInterval(interval)
  }, [apiUrl])

  const fetchAlerts = async () => {
    try {
      const response = await fetch(`${apiUrl}/api/alerts`)
      const data = await response.json()
      setAlerts(data.alerts || [])
    } catch (error) {
      console.error("Error fetching alerts:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchInterventions = async () => {
    try {
      const response = await fetch(`${apiUrl}/api/interventions`)
      const data = await response.json()
      setInterventions(data.interventions || [])
    } catch (error) {
      console.error("Error fetching interventions:", error)
    }
  }

  const handleAcknowledgeAlert = (studentId: string) => {
    const newAcknowledged = new Set(acknowledgedAlerts)
    newAcknowledged.add(studentId)
    setAcknowledgedAlerts(newAcknowledged)
  }

  const handleCreateIntervention = async (alert: Alert) => {
    try {
      const response = await fetch(`${apiUrl}/api/interventions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          student_id: alert.student_id,
          intervention_type: alert.intervention,
          description: alert.message,
          priority: alert.severity === "critical" ? "high" : "medium",
        }),
      })
      if (response.ok) {
        alert("Intervention created successfully!")
        fetchInterventions()
      }
    } catch (error) {
      console.error("Error creating intervention:", error)
    }
  }

  const getAlertIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertCircle className="h-5 w-5 text-destructive" />
      case "warning":
        return <Clock className="h-5 w-5 text-yellow-500" />
      default:
        return <CheckCircle className="h-5 w-5 text-green-500" />
    }
  }

  const getInterventionStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const criticalAlerts = alerts.filter((a) => a.severity === "critical")
  const warningAlerts = alerts.filter((a) => a.severity === "warning")
  const activeInterventions = interventions.filter((i) => i.status !== "completed")

  return (
    <div className="space-y-6">
      <div className="flex gap-2 border-b">
        <button
          onClick={() => setActiveTab("alerts")}
          className={`px-4 py-2 font-medium ${activeTab === "alerts" ? "border-b-2 border-primary text-primary" : "text-muted-foreground"}`}
        >
          Alerts ({alerts.length})
        </button>
        <button
          onClick={() => setActiveTab("interventions")}
          className={`px-4 py-2 font-medium ${activeTab === "interventions" ? "border-b-2 border-primary text-primary" : "text-muted-foreground"}`}
        >
          Interventions ({activeInterventions.length})
        </button>
      </div>

      {activeTab === "alerts" && (
        <>
          {/* Critical Alerts */}
          {criticalAlerts.length > 0 && (
            <Card className="border-destructive/50 bg-destructive/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-destructive" />
                  Critical Alerts ({criticalAlerts.length})
                </CardTitle>
                <CardDescription>Immediate action required</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {criticalAlerts.map((alert, idx) => (
                    <div
                      key={idx}
                      className={`flex items-start gap-3 rounded-lg border p-4 ${acknowledgedAlerts.has(alert.student_id) ? "opacity-60" : ""}`}
                    >
                      {getAlertIcon(alert.severity)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{alert.student_id}</h4>
                          <Badge variant="destructive">{alert.severity}</Badge>
                          {alert.risk_score && (
                            <Badge variant="outline">{(alert.risk_score * 100).toFixed(1)}% risk</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{alert.message}</p>
                        <p className="mt-2 text-xs font-medium text-foreground">
                          Suggested: <span className="text-primary">{alert.intervention}</span>
                        </p>
                        {alert.timestamp && (
                          <p className="mt-1 text-xs text-muted-foreground">
                            {new Date(alert.timestamp).toLocaleString()}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleCreateIntervention(alert)}
                          disabled={acknowledgedAlerts.has(alert.student_id)}
                        >
                          <Zap className="mr-1 h-4 w-4" />
                          Create Intervention
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleAcknowledgeAlert(alert.student_id)}
                          disabled={acknowledgedAlerts.has(alert.student_id)}
                        >
                          {acknowledgedAlerts.has(alert.student_id) ? "Acknowledged" : "Acknowledge"}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Warning Alerts */}
          {warningAlerts.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-yellow-500" />
                  Warning Alerts ({warningAlerts.length})
                </CardTitle>
                <CardDescription>Monitor these students closely</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {warningAlerts.map((alert, idx) => (
                    <div key={idx} className="flex items-start gap-3 rounded-lg border p-4">
                      {getAlertIcon(alert.severity)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{alert.student_id}</h4>
                          <Badge variant="secondary">{alert.severity}</Badge>
                          {alert.risk_score && (
                            <Badge variant="outline">{(alert.risk_score * 100).toFixed(1)}% risk</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{alert.message}</p>
                        <p className="mt-2 text-xs font-medium text-foreground">
                          Suggested: <span className="text-primary">{alert.intervention}</span>
                        </p>
                      </div>
                      <Button size="sm" variant="outline" onClick={() => handleCreateIntervention(alert)}>
                        <Zap className="mr-1 h-4 w-4" />
                        Create Intervention
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {loading && alerts.length === 0 && (
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground">Loading alerts...</p>
              </CardContent>
            </Card>
          )}

          {!loading && alerts.length === 0 && (
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground">No active alerts. All students are performing well!</p>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {activeTab === "interventions" && (
        <Card>
          <CardHeader>
            <CardTitle>Active Interventions</CardTitle>
            <CardDescription>Track and manage student support interventions</CardDescription>
          </CardHeader>
          <CardContent>
            {activeInterventions.length === 0 ? (
              <p className="text-muted-foreground">No active interventions</p>
            ) : (
              <div className="space-y-3">
                {activeInterventions.map((intervention, idx) => (
                  <div key={idx} className="flex items-start gap-3 rounded-lg border p-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold">{intervention.student_id}</h4>
                        <Badge className={getInterventionStatusColor(intervention.status)}>{intervention.status}</Badge>
                        <Badge variant="outline">{intervention.intervention_type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{intervention.description}</p>
                      {intervention.notes && (
                        <p className="mt-2 text-xs text-foreground">Notes: {intervention.notes}</p>
                      )}
                      {intervention.created_at && (
                        <p className="mt-1 text-xs text-muted-foreground">
                          Created: {new Date(intervention.created_at).toLocaleString()}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
