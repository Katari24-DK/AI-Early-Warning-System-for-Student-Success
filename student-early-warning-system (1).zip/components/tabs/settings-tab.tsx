"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"

export default function SettingsTab() {
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [alertFrequency, setAlertFrequency] = useState("daily")
  const [notificationEmail, setNotificationEmail] = useState("educator@example.com")

  const handleSave = () => {
    localStorage.setItem("emailNotifications", emailNotifications.toString())
    localStorage.setItem("alertFrequency", alertFrequency)
    localStorage.setItem("notificationEmail", notificationEmail)
    alert("Settings saved!")
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Notification Settings</CardTitle>
          <CardDescription>Configure how you receive alerts</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Notification Email</label>
            <Input value={notificationEmail} onChange={(e) => setNotificationEmail(e.target.value)} type="email" />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Alert Frequency</label>
            <Select value={alertFrequency} onValueChange={setAlertFrequency}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="realtime">Real-time</SelectItem>
                <SelectItem value="daily">Daily Digest</SelectItem>
                <SelectItem value="weekly">Weekly Summary</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={emailNotifications}
              onChange={(e) => setEmailNotifications(e.target.checked)}
              id="email-notifications"
            />
            <label htmlFor="email-notifications" className="text-sm font-medium">
              Enable email notifications
            </label>
          </div>

          <Button onClick={handleSave} className="w-full">
            Save Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
