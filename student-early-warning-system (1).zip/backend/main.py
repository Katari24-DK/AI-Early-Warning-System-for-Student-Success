from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pandas as pd
import numpy as np
import pickle
import os
from datetime import datetime
from typing import List, Optional
import xgboost as xgb
from langgraph_agent import StudentRiskAgent

app = FastAPI(title="Student Early Warning System API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize agent
agent = StudentRiskAgent()

# Data models
class StudentRecord(BaseModel):
    student_id: str
    attendance: float
    grade_average: float
    time_on_task: float
    lms_logins_per_week: float
    missing_assignments: int
    prior_risk_flag: int

class PredictionRequest(BaseModel):
    risk_threshold: float = 0.6

# In-memory storage
student_data = []
predictions_cache = []
alerts_cache = []

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.post("/api/analyze-student")
async def analyze_student(record: StudentRecord):
    """Analyze a single student record"""
    try:
        # Prepare features
        features = np.array([[
            record.attendance,
            record.grade_average,
            record.time_on_task,
            record.lms_logins_per_week,
            record.missing_assignments,
            record.prior_risk_flag
        ]])
        
        # Get prediction from agent
        result = await agent.analyze_student(record.dict())
        
        # Store in cache
        student_data.append(record.dict())
        
        return {
            "student_id": record.student_id,
            "risk_score": result.get("risk_score", 0.0),
            "risk_level": result.get("risk_level", "unknown"),
            "interventions": result.get("interventions", []),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/upload-csv")
async def upload_csv(file: UploadFile = File(...)):
    """Upload and process CSV file"""
    try:
        contents = await file.read()
        df = pd.read_csv(pd.io.common.StringIO(contents.decode('utf-8')))
        
        records_processed = 0
        for _, row in df.iterrows():
            record = StudentRecord(
                student_id=str(row.get('student_id', '')),
                attendance=float(row.get('attendance', 0)),
                grade_average=float(row.get('grade_average', 0)),
                time_on_task=float(row.get('time_on_task', 0)),
                lms_logins_per_week=float(row.get('lms_logins_per_week', 0)),
                missing_assignments=int(row.get('missing_assignments', 0)),
                prior_risk_flag=int(row.get('prior_risk_flag', 0))
            )
            student_data.append(record.dict())
            records_processed += 1
        
        return {
            "records_processed": records_processed,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/predict-all")
async def predict_all(request: PredictionRequest):
    """Run predictions on all students"""
    try:
        predictions = []
        alerts = []
        
        for student in student_data:
            result = await agent.analyze_student(student)
            risk_score = result.get("risk_score", 0.0)
            
            prediction = {
                "student_id": student["student_id"],
                "risk_score": risk_score,
                "risk_level": "At Risk" if risk_score > request.risk_threshold else "Safe",
                "interventions": result.get("interventions", [])
            }
            predictions.append(prediction)
            
            # Generate alerts for at-risk students
            if risk_score > request.risk_threshold:
                alert = {
                    "student_id": student["student_id"],
                    "severity": "critical" if risk_score > 0.8 else "warning",
                    "message": f"Student at risk with score {risk_score:.2%}",
                    "intervention": result.get("interventions", ["Schedule meeting"])[0]
                }
                alerts.append(alert)
        
        predictions_cache.extend(predictions)
        alerts_cache.extend(alerts)
        
        return {
            "predictions": predictions,
            "alerts_generated": len(alerts),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/alerts")
async def get_alerts():
    """Get all active alerts"""
    return {
        "alerts": alerts_cache[-20:],  # Return last 20 alerts
        "total": len(alerts_cache),
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/statistics")
async def get_statistics():
    """Get system statistics"""
    if not predictions_cache:
        return {
            "total_students": len(student_data),
            "total_predictions": 0,
            "at_risk_count": 0,
            "safe_count": 0
        }
    
    at_risk = sum(1 for p in predictions_cache if p["risk_level"] == "At Risk")
    safe = len(predictions_cache) - at_risk
    
    return {
        "total_students": len(student_data),
        "total_predictions": len(predictions_cache),
        "at_risk_count": at_risk,
        "safe_count": safe,
        "at_risk_percentage": (at_risk / len(predictions_cache) * 100) if predictions_cache else 0
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
