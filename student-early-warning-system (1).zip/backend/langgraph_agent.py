import anthropic
from typing import Any, Dict, List
import json
from datetime import datetime

class StudentRiskAgent:
    """LangGraph-based agent for analyzing student risk"""
    
    def __init__(self):
        self.client = anthropic.Anthropic()
        self.model = "claude-3-5-sonnet-20241022"
        self.risk_thresholds = {
            "critical": 0.8,
            "high": 0.6,
            "medium": 0.4,
            "low": 0.2
        }
    
    async def analyze_student(self, student_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze student data and generate risk assessment"""
        
        # Calculate risk score based on features
        risk_score = self._calculate_risk_score(student_data)
        
        # Generate interventions using Claude
        interventions = await self._generate_interventions(student_data, risk_score)
        
        return {
            "student_id": student_data.get("student_id"),
            "risk_score": risk_score,
            "risk_level": self._get_risk_level(risk_score),
            "interventions": interventions,
            "timestamp": datetime.now().isoformat()
        }
    
    def _calculate_risk_score(self, student_data: Dict[str, Any]) -> float:
        """Calculate risk score from student features"""
        
        # Normalize features (0-1 scale)
        attendance_score = 1 - (student_data.get("attendance", 100) / 100)  # Lower attendance = higher risk
        grade_score = 1 - (max(0, min(100, student_data.get("grade_average", 0))) / 100)  # Lower grades = higher risk
        task_score = 1 - (min(100, student_data.get("time_on_task", 0)) / 100)  # Less time = higher risk
        login_score = 1 - (min(10, student_data.get("lms_logins_per_week", 0)) / 10)  # Fewer logins = higher risk
        assignment_score = min(1, student_data.get("missing_assignments", 0) / 10)  # More missing = higher risk
        prior_flag_score = float(student_data.get("prior_risk_flag", 0))  # Prior flag = higher risk
        
        # Weighted combination
        weights = {
            "attendance": 0.25,
            "grade": 0.25,
            "task": 0.15,
            "login": 0.15,
            "assignment": 0.15,
            "prior": 0.05
        }
        
        risk_score = (
            weights["attendance"] * attendance_score +
            weights["grade"] * grade_score +
            weights["task"] * task_score +
            weights["login"] * login_score +
            weights["assignment"] * assignment_score +
            weights["prior"] * prior_flag_score
        )
        
        return min(1.0, max(0.0, risk_score))
    
    def _get_risk_level(self, risk_score: float) -> str:
        """Determine risk level from score"""
        if risk_score >= self.risk_thresholds["critical"]:
            return "Critical"
        elif risk_score >= self.risk_thresholds["high"]:
            return "High"
        elif risk_score >= self.risk_thresholds["medium"]:
            return "Medium"
        elif risk_score >= self.risk_thresholds["low"]:
            return "Low"
        return "Safe"
    
    async def _generate_interventions(self, student_data: Dict[str, Any], risk_score: float) -> List[str]:
        """Generate tailored interventions using Claude"""
        
        # Identify risk factors
        risk_factors = []
        if student_data.get("attendance", 100) < 80:
            risk_factors.append("Low attendance")
        if student_data.get("grade_average", 100) < 70:
            risk_factors.append("Low grades")
        if student_data.get("time_on_task", 100) < 50:
            risk_factors.append("Low engagement")
        if student_data.get("lms_logins_per_week", 10) < 2:
            risk_factors.append("Infrequent LMS access")
        if student_data.get("missing_assignments", 0) > 2:
            risk_factors.append("Missing assignments")
        
        # Use Claude to generate interventions
        prompt = f"""
        Based on the following student risk profile, suggest 2-3 specific, actionable interventions:
        
        Risk Score: {risk_score:.2%}
        Risk Factors: {', '.join(risk_factors) if risk_factors else 'None identified'}
        Attendance: {student_data.get('attendance', 'N/A')}%
        Grade Average: {student_data.get('grade_average', 'N/A')}
        Time on Task: {student_data.get('time_on_task', 'N/A')} minutes
        LMS Logins/week: {student_data.get('lms_logins_per_week', 'N/A')}
        Missing Assignments: {student_data.get('missing_assignments', 'N/A')}
        
        Provide interventions as a JSON array of strings. Be specific and actionable.
        """
        
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=500,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            response_text = message.content[0].text
            
            # Parse interventions from response
            try:
                # Try to extract JSON array
                start = response_text.find('[')
                end = response_text.rfind(']') + 1
                if start != -1 and end > start:
                    interventions = json.loads(response_text[start:end])
                    return interventions[:3]  # Return top 3
            except:
                pass
            
            # Fallback: return default interventions based on risk factors
            return self._get_default_interventions(risk_factors, risk_score)
            
        except Exception as e:
            print(f"Error generating interventions: {e}")
            return self._get_default_interventions(risk_factors, risk_score)
    
    def _get_default_interventions(self, risk_factors: List[str], risk_score: float) -> List[str]:
        """Get default interventions based on risk factors"""
        interventions = []
        
        if "Low attendance" in risk_factors:
            interventions.append("Schedule meeting with student to discuss attendance barriers")
        if "Low grades" in risk_factors:
            interventions.append("Refer to tutoring services or academic support")
        if "Low engagement" in risk_factors:
            interventions.append("Increase check-ins and provide additional resources")
        if "Infrequent LMS access" in risk_factors:
            interventions.append("Send reminder emails and provide technical support")
        if "Missing assignments" in risk_factors:
            interventions.append("Create assignment completion plan with student")
        
        if not interventions:
            if risk_score > 0.8:
                interventions.append("Escalate to academic advisor for comprehensive support plan")
            elif risk_score > 0.6:
                interventions.append("Increase monitoring and provide proactive support")
            else:
                interventions.append("Continue regular monitoring")
        
        return interventions[:3]
