"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import DataTab from "@/components/tabs/data-tab"
import PredictTab from "@/components/tabs/predict-tab"
import AlertsTab from "@/components/tabs/alerts-tab"
import SettingsTab from "@/components/tabs/settings-tab"
import ActivityLogTab from "@/components/tabs/activity-log-tab"
import FilesTab from "@/components/tabs/files-tab"

export default function Home() {
  const [apiUrl, setApiUrl] = useState("http://127.0.0.1:8000")
  const [riskThreshold, setRiskThreshold] = useState([0.6])
  const [model, setModel] = useState("xgboost")
  const [activeTab, setActiveTab] = useState("data")

  const handleSaveSettings = () => {
    localStorage.setItem("apiUrl", apiUrl)
    localStorage.setItem("riskThreshold", riskThreshold[0].toString())
    localStorage.setItem("model", model)
    alert("Settings saved successfully!")
  }

  const handleTestConnection = async () => {
    try {
      const response = await fetch(`${apiUrl}/health`)
      if (response.ok) {
        alert("API connection successful!")
      } else {
        alert("API connection failed!")
      }
    } catch (error) {
      alert("Error connecting to API: " + error)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-primary text-primary-foreground">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold">AI Early Warning System for Student Success</h1>
          <p className="mt-2 text-sm opacity-90">Early warning, engagement insights, and actionable interventions</p>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-4">
          {/* Sidebar Controls */}
          <aside className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle className="text-lg">Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* API URL */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">API URL</label>
                  <Input
                    value={apiUrl}
                    onChange={(e) => setApiUrl(e.target.value)}
                    placeholder="http://127.0.0.1:8000"
                    className="text-sm"
                  />
                </div>

                {/* Risk Threshold */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Risk Threshold</label>
                  <div className="space-y-2">
                    <Slider
                      value={riskThreshold}
                      onValueChange={setRiskThreshold}
                      min={0}
                      max={1}
                      step={0.01}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>0.00</span>
                      <span className="font-semibold text-foreground">{riskThreshold[0].toFixed(2)}</span>
                      <span>1.00</span>
                    </div>
                  </div>
                </div>

                {/* Model Selection */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Model</label>
                  <Select value={model} onValueChange={setModel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="xgboost">XGBoost</SelectItem>
                      <SelectItem value="random_forest">Random Forest</SelectItem>
                      <SelectItem value="logistic_regression">Logistic Regression</SelectItem>
                      <SelectItem value="neural_network">Neural Network</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2 pt-4">
                  <Button onClick={handleSaveSettings} className="w-full" variant="default">
                    Save Settings
                  </Button>
                  <Button onClick={handleTestConnection} className="w-full bg-transparent" variant="outline">
                    Test API Connection
                  </Button>
                </div>
              </CardContent>
            </Card>
          </aside>

          {/* Main Content */}
          <main className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-6 border-b">
                <TabsTrigger value="data">Data</TabsTrigger>
                <TabsTrigger value="predict">Predict</TabsTrigger>
                <TabsTrigger value="alerts">Alerts</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
                <TabsTrigger value="activity">Activity Log</TabsTrigger>
                <TabsTrigger value="files">Files</TabsTrigger>
              </TabsList>

              <TabsContent value="data" className="space-y-6">
                <DataTab apiUrl={apiUrl} riskThreshold={riskThreshold[0]} />
              </TabsContent>

              <TabsContent value="predict" className="space-y-6">
                <PredictTab apiUrl={apiUrl} riskThreshold={riskThreshold[0]} />
              </TabsContent>

              <TabsContent value="alerts" className="space-y-6">
                <AlertsTab apiUrl={apiUrl} />
              </TabsContent>

              <TabsContent value="settings" className="space-y-6">
                <SettingsTab />
              </TabsContent>

              <TabsContent value="activity" className="space-y-6">
                <ActivityLogTab />
              </TabsContent>

              <TabsContent value="files" className="space-y-6">
                <FilesTab />
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  )
}
